# Source Cards (RemNote Import)

Import sources for **CRS 001 — complete (2026-06-19)**. Theory in `study_pages/` first; cards for spaced repetition.

Format: `../../../planning/remnote_source_cards.md`

---

## Import order

| # | File | Layer | Cards |
|---|------|-------|------:|
| 1 | `01 coursera_ibm_rag_dev...undations_learning_mode.md` | M1 theory | 15 |
| 2 | `02 coursera_ibm_rag_dev...echniques_learning_mode.md` | M1 prompts | 20 |
| 3 | `03 coursera_ibm_rag_dev...ates_chat_learning_mode.md` | M1 templates | 20 |
| 4 | `04 coursera_ibm_rag_dev...s_parsers_learning_mode.md` | M2 LCEL/parsers | 25 |
| 5 | `05_01_prompt_and_chat_coding.md` | Code | 15 |
| 6 | `05_02_few_shot_and_lcel_coding.md` | Code | 15 |
| 7 | `05_03_parallel_json_structured_coding.md` | Code | 16 |
| 8 | `05_04_history_and_provider_coding.md` | Code | 15 |
| 9 | `05_05_selective_reinforcement.md` | Traps | 19 |
| 10 | `05_06_invoke_and_vocabulary.md` | Invoke trio | 12 |
| 11 | `05_07_module2_quiz_reinforcement.md` | M2 quiz | 14 |
| 12 | `05_08_module3_lab_and_quiz.md` | **M3 lab + final quiz** | 22 |
| 13 | `05_09_capstone_code_patterns.md` | **Capstones 1–4** | 14 |

**Total: ~222 cards**

---

## After import

1. Parent doc: `CRS 001 — Develop Generative AI (Complete)`
2. Daily: match card deck to what you re-run in `lab/python/` or capstones
3. Quiz traps: prioritize `05_07`, `05_08` (fine-tune vs RAG, sovereignty, model eval)

---

## Card formats

**MC** — `>>A)` marks correct option.

**Cloze** — `__________` → answer after arrow.

---

## Related docs

- [COURSE_COMPLETE.md](../study_pages/COURSE_COMPLETE.md)
- [CODE_CATALOG.md](../lab/CODE_CATALOG.md)
- [CAPSTONE_CODE_GUIDE.md](../docs/CAPSTONE_CODE_GUIDE.md)

Filenames `01`–`04` keep RemNote export truncation — do not rename without re-export.